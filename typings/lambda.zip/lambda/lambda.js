var request = require('request');
var util = require('util');

var url = "https://echodroid:alexasdk406@9247ef04.ngrok.io/notifications"

/**
 * The App ID for this skill
 */
var APP_ID = "amzn1.echo-sdk-ams.app.16213a1d-1d9f-494d-8565-f3b9f5290d87";

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

var Echodroid = function () {
	AlexaSkill.call(this, APP_ID);
};

function ReadNotifications()
{
	request({
		url: url    
	}, function(error, body, response) {
		// console.log(JSON.parse(body.body));
		var notifications = JSON.parse(body.body);
		// console.log(notifications.length);
		return ParseNotifications(notifications);
	});
};

function ParseNotifications(notifications) {
	var readout;
    var notificationTerm;
	if(notifications.length == 1) {
		notificationTerm = 'notification';
	}
	else {
		notificationTerm = 'notifications';
	}

	var readout = util.format("You have %d %s. ", notifications.length, notificationTerm);
	var count = 1;
    notifications.forEach(function(notification) {
		readout += util.format("Notification %d, from %s. Title: %s. Body: %s.", count++, notification.push.application_name, notification.push.title, notification.push.body);
    }, this);

	return readout;
}

// Extend AlexaSkill
Echodroid.prototype = Object.create(AlexaSkill.prototype);
Echodroid.prototype.constructor = Echodroid;

Echodroid.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("Echodroid onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

Echodroid.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("Echodroid onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    var speechOutput = "Welcome to Echodroid, you can say what are my notifications";
    var repromptText = "You can say what are my notifications";
    response.ask(speechOutput, repromptText);
};

Echodroid.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("Echodroid onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

Echodroid.prototype.intentHandlers = {
    // register custom intent handlers
    "GetNotifications": function (intent, session, response) {
        response.tell(ReadNotifications());
    },
    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can say hello to me!", "You can say hello to me!");
    }
};

exports.handler = function (event, context) {
    // Create an instance of the HelloWorld skill.
    var echodroid = new Echodroid();
    echodroid.execute(event, context);
};